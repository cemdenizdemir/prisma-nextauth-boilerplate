const password_min_length = 1;
const bcrypt_salt_rounds = 10;

export { password_min_length, bcrypt_salt_rounds };
