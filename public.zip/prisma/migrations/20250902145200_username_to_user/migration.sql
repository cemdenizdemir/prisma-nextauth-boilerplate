-- AlterTable
ALTER TABLE "public"."User" ADD COLUMN     "username" TEXT;
